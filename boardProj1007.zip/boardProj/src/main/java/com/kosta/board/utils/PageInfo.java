package com.kosta.board.utils;

public class PageInfo {

	private Integer curPage;
	private Integer allPage;  // 방향키(마지막 페이지가서) 활성화 비활성화를 계산하기 위해 필요함
	private Integer startPage; // 시작 버튼 숫자
	private Integer endPage;  // 끝 버튼 숫자
	
	
	
	
	
	
	public Integer getCurPage() {
		return curPage;
	}
	public void setCurPage(Integer curPage) {
		this.curPage = curPage;
	}
	public Integer getAllPage() {
		return allPage;
	}
	public void setAllPage(Integer allPage) {
		this.allPage = allPage;
	}
	public Integer getStartPage() {
		return startPage;
	}
	public void setStartPage(Integer startPage) {
		this.startPage = startPage;
	}
	public Integer getEndPage() {
		return endPage;
	}
	public void setEndPage(Integer endPage) {
		this.endPage = endPage;
	}
	
	
}
